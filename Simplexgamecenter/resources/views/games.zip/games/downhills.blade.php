@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: downhills --}}
  @include('games.partials.show-content')
@endsection
