@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: street-fighter --}}
  @include('games.partials.show-content')
@endsection
