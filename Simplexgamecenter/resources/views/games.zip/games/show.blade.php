@extends('layouts.app')

@section('content')
  @include('games.partials.show-content')
@endsection
