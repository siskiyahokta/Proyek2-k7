@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: injustice --}}
  @include('games.partials.show-content')
@endsection
