@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: overcooked --}}
  @include('games.partials.show-content')
@endsection
