@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: gta5 --}}
  @include('games.partials.show-content')
@endsection
