@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: injustice-2 --}}
  @include('games.partials.show-content')
@endsection
