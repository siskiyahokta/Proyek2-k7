@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: nba-2k25 --}}
  @include('games.partials.show-content')
@endsection
