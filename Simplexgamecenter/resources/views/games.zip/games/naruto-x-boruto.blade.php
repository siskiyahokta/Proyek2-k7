@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: naruto-x-boruto --}}
  @include('games.partials.show-content')
@endsection
