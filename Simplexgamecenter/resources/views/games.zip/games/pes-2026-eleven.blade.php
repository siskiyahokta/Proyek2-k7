@extends('layouts.app')
@section('content')
  {{-- halaman detail khusus slug: pes-2026-eleven --}}
  @include('games.partials.show-content')
@endsection
